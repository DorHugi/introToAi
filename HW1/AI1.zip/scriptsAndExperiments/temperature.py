import numpy as np
from matplotlib import pyplot as plt

X = np.array([400,900,390,1000,550])

# TODO : Write the code as explained in the instructions
raise NotImplementedError